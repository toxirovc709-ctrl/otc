from __future__ import annotations

from decimal import Decimal
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Telegram ---
    bot_token: str
    admin_ids: str = ""

    # --- Database ---
    db_path: str = str(BASE_DIR / "data" / "guarant.db")

    # --- TON ---
    ton_api_base: str = "https://toncenter.com/api/v3"
    ton_api_key: str = ""
    # Hamyon manzili — bu yerga xaridorlar to'lov yuboradi
    escrow_wallet_address: str = ""
    # Chiqim uchun mnemonic. BOSH SERVERDA OCHIQ SAQLAMA.
    escrow_mnemonic: str = ""
    ton_is_testnet: bool = True

    # --- Komissiya ---
    fee_percent: Decimal = Decimal("3.0")
    fee_min_ton: Decimal = Decimal("0.5")
    # Katta bitimlarda pasaytirilgan stavka
    fee_large_threshold_ton: Decimal = Decimal("500")
    fee_large_percent: Decimal = Decimal("1.5")

    # --- Xavfsizlik chegaralari ---
    # Bitta bitimda ruxsat etilgan eng katta summa
    max_deal_ton: Decimal = Decimal("100")
    # 10 TON dan past bitimlarda minimal komissiya foizni haddan tashqari
    # oshirib yuboradi (1 TON'lik bitimda 50%), shuning uchun chegara shu.
    min_deal_ton: Decimal = Decimal("10")
    # Bir kunda avtomatik chiqariladigan eng katta umumiy summa
    daily_payout_cap_ton: Decimal = Decimal("500")
    # Shu summadan katta chiqimlar admin tasdig'ini kutadi
    manual_approval_above_ton: Decimal = Decimal("50")
    # Butun avtomatik chiqimni to'xtatuvchi kalit
    payouts_enabled: bool = True

    # --- Taymerlar (soniyada) ---
    payment_window_sec: int = 30 * 60
    gift_window_sec: int = 30 * 60
    watcher_interval_sec: int = 8

    # To'lov summasi mos kelishi uchun ruxsat etilgan farq
    amount_tolerance_ton: Decimal = Decimal("0.05")

    @field_validator("fee_percent", "fee_large_percent")
    @classmethod
    def _sane_percent(cls, v: Decimal) -> Decimal:
        if not (Decimal("0") <= v <= Decimal("15")):
            raise ValueError("Komissiya 0-15% oralig'ida bo'lishi kerak")
        return v

    @property
    def admins(self) -> set[int]:
        out: set[int] = set()
        for chunk in self.admin_ids.replace(";", ",").split(","):
            chunk = chunk.strip()
            if chunk.isdigit():
                out.add(int(chunk))
        return out


settings = Settings()  # type: ignore[call-arg]
