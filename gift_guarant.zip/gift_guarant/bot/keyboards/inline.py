from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.emoji import plain
from bot.locales.texts import LANGS, t


def language_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for code, label in LANGS.items():
        kb.button(text=label, callback_data=f"lang:{code}")
    kb.adjust(3)
    return kb.as_markup()


def main_menu_kb(lang: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text=f"{plain('wallet')} {t('menu_wallet', lang)}", callback_data="wallet")
    kb.button(
        text=f"{plain('handshake')} {t('menu_create', lang)}", callback_data="deal:new"
    )
    kb.button(text=f"{plain('list')} {t('menu_deals', lang)}", callback_data="deals")
    kb.button(
        text=f"{plain('settings')} {t('menu_settings', lang)}", callback_data="settings"
    )
    kb.adjust(1, 1, 2)
    return kb.as_markup()


def back_kb(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"{plain('back')} {t('menu_back', lang)}",
                    callback_data="menu",
                )
            ]
        ]
    )


def wallet_kb(lang: str, wallets: list) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    if wallets:
        for w in wallets:
            short = f"{w.address[:6]}…{w.address[-4:]}"
            kb.button(text=f"{plain('ton')} {short}", callback_data=f"wallet:use:{w.id}")
    else:
        kb.button(text=f"⚪️ {t('wallet_empty', lang)}", callback_data="noop")
    kb.button(text=f"{plain('wallet')} {t('wallet_add', lang)}", callback_data="wallet:add")
    kb.button(text=f"{plain('back')} {t('menu_back', lang)}", callback_data="menu")
    kb.adjust(1)
    return kb.as_markup()


def deal_type_kb(lang: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text=f"{plain('gift')} {t('type_gift', lang)}", callback_data="deal:kind:gift")
    kb.button(
        text=f"{plain('channel')} {t('type_channel', lang)}",
        callback_data="deal:kind:channel",
    )
    kb.button(
        text=f"{plain('account')} {t('type_account', lang)}",
        callback_data="deal:kind:account",
    )
    kb.button(text=f"{plain('back')} {t('menu_back', lang)}", callback_data="menu")
    kb.adjust(2, 1, 1)
    return kb.as_markup()


def settings_kb(lang: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(
        text=f"{plain('user')} {t('settings_referrals', lang)}", callback_data="referrals"
    )
    kb.button(
        text=f"{plain('globe')} {t('settings_language', lang)}", callback_data="language"
    )
    kb.button(text=f"{plain('back')} {t('menu_back', lang)}", callback_data="menu")
    kb.adjust(2, 1)
    return kb.as_markup()


def share_deal_kb(lang: str, bot_username: str, code: str) -> InlineKeyboardMarkup:
    url = f"https://t.me/{bot_username}?start=deal_{code}"
    kb = InlineKeyboardBuilder()
    kb.button(
        text=f"{plain('link')} Ulashish",
        switch_inline_query=f"\n{url}",
    )
    kb.button(text=f"{plain('back')} {t('menu_back', lang)}", callback_data="menu")
    kb.adjust(1)
    return kb.as_markup()
